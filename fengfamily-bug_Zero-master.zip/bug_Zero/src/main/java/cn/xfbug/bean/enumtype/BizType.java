package cn.xfbug.bean.enumtype;

/**
 * @author Fengfamily
 */
public enum BizType {

    VIP("VIP升级")
    ;

    BizType(String desc) {
        this.desc = desc;
    }

    private String desc;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public static BizType getBizType(String enumName){
        BizType bizType = null;
        for(BizType biz : BizType.values()){
            if(biz.name().equals(enumName)){
                bizType = biz;
                break;
            }
        }
        return bizType;
    }

}
