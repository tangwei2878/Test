/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : xfbugh

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2018-04-10 19:00:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_limitrule
-- ----------------------------
DROP TABLE IF EXISTS `t_limitrule`;
CREATE TABLE `t_limitrule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `limit_Value` varchar(20) DEFAULT NULL,
  `biz_Type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_limitrule
-- ----------------------------
INSERT INTO `t_limitrule` VALUES ('1', '192.168.33.12', 'VIP');
INSERT INTO `t_limitrule` VALUES ('2', '127.0.0.1', 'VIP');
