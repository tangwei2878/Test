# bug缺陷管理系统

#### 项目介绍
一款专业化bug缺陷流程管理工具
后续上新，敬请关注

#### 软件架构
软件架构说明,采用springboot+spring mvc实现



#### 演示地址
http://www.xfbug.com

